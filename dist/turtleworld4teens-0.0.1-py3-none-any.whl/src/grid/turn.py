from enum import Enum

class Turn(Enum):
    LEFT = 2
    RIGHT = 3