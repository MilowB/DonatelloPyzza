# TurtleWorld4Teens

A simple environment to help teenagers learning Python in high school. 
A turtle can move in a grid and touch each cell until it finds the salad.

You can manually create the grid world in which the turtle is moving or generate it automatically.

# How to use ?

Install pygame :

> python3 -m pip install -U pygame --user

OR if not working :

> python3 -m pip install pygame==2.0.0.dev6

Then :

> python main.py
